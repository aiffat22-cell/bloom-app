package com.example.bloomapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class SignupActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

  DatabaseHelper db = new DatabaseHelper(this);
        View btn = findViewById(R.id.btnSignupAction);

        if (btn != null) {
            btn.setOnClickListener(v -> {
                EditText nBox = findViewById(R.id.inputName);
                EditText uBox = findViewById(R.id.inputUsername);
                EditText pBox = findViewById(R.id.inputPassword);
                EditText cBox = findViewById(R.id.inputConfirmPass); // ID must match XML

                String n = nBox.getText().toString();
                String u = uBox.getText().toString();
                String p = pBox.getText().toString();
                String c = cBox != null ? cBox.getText().toString() : "";

                if (u.isEmpty() || p.isEmpty()) {
                    Toast.makeText(this, "Fill fields", Toast.LENGTH_SHORT).show();
                } else if (!p.equals(c) && cBox != null) {
                    Toast.makeText(this, "Passwords must match", Toast.LENGTH_SHORT).show();
                } else {
                    if (db.addUser(n, u, p)) {
                        new AppPreferences(this).setLoggedIn(true, u);
                        Intent i = new Intent(this, MainActivity.class);
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                    } else {
                        Toast.makeText(this, "Username exists", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        View back = findViewById(R.id.btnBack);
        if(back != null) back.setOnClickListener(v -> finish());
    }
}