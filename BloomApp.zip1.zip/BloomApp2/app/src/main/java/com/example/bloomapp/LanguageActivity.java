package com.example.bloomapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class LanguageActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        AppPreferences prefs = new AppPreferences(this);
        setupLangBtn(R.id.btnEnglish, "en", prefs);
        setupLangBtn(R.id.btnArabic, "ar", prefs);
    }

    private void setupLangBtn(int id, String code, AppPreferences prefs) {
        View btn = findViewById(id);
        if (btn != null) {
            btn.setOnClickListener(v -> {
                prefs.setLanguage(code);
                Intent i = new Intent(this, WelcomeActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            });
        }
    }
}