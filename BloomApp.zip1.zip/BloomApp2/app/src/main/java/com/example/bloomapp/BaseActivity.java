package com.example.bloomapp;

import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        AppPreferences prefs = new AppPreferences(newBase);
        super.attachBaseContext(LocaleHelper.setLocale(newBase, prefs.getLanguage()));
    }
}