package com.example.bloomapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class WelcomeActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        setNav(R.id.btnGetStarted, AuthSelectionActivity.class);
        setNav(R.id.btnNext, AuthSelectionActivity.class);

        // Safe Back Button
        View btnBack = findViewById(R.id.btnBack);
        if(btnBack != null) btnBack.setOnClickListener(v -> finish());
    }

    private void setNav(int id, Class<?> target) {
        View v = findViewById(id);
        if(v != null) v.setOnClickListener(view -> startActivity(new Intent(this, target)));
    }
}