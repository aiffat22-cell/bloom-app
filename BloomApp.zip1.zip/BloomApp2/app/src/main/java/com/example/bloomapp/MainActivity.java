package com.example.bloomapp;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.CalendarView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView; // Added import
import java.util.Random;

public class MainActivity extends BaseActivity {

    private boolean isLetterOpen = false;
    private String selectedDate = "";

    // Arrays for random generation
    private String[] letters = {
            "A: Ambition is enthusiasm with a purpose.",
            "B: Be a first-rate version of yourself.",
            "C: Courage is the first of human qualities.",
            "D: Dreams don't work unless you do."
            // Add more...
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // --- 1. SAFE VIEW FINDING (Prevents Crashing) ---
        // We look for every view and check if it is null before using it

        ImageView lavLeft = findViewById(R.id.lavenderLeft);
        ImageView lavRight = findViewById(R.id.lavenderRight);
        ImageView flowerTop = findViewById(R.id.flowerBgTop);
        ImageView flowerMid = findViewById(R.id.flowerBgMid);

        SeekBar sb = findViewById(R.id.energySeekBar);
        TextView txtVal = findViewById(R.id.lblSeekValue);
        TextView txtRes = findViewById(R.id.txtSecretResult);
        View btnReveal = findViewById(R.id.btnOpenLetter);

        CalendarView cal = findViewById(R.id.mainCalendar);
        TextView dateLbl = findViewById(R.id.lblDateTodo);

        // --- 2. ANIMATIONS (Only if views exist) ---
        if(lavLeft != null) startSwaying(lavLeft, 3500, -5f, 5f);
        if(lavRight != null) startSwaying(lavRight, 4500, 10f, 20f);
        if(flowerTop != null) rotateObj(flowerTop, 25000);
        if(flowerMid != null) rotateObj(flowerMid, 30000);

        // --- 3. SLIDER LOGIC ---
        if (sb != null && txtVal != null) {
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                    txtVal.setText("Selected: " + Math.max(1, i));
                }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {}
            });
        }

        // --- 4. OPEN LETTER LOGIC ---
        if (btnReveal != null && txtRes != null) {
            btnReveal.setOnClickListener(v -> {
                if(!isLetterOpen) {
                    // Try to hide flowers if they exist
                    if(lavLeft != null) hideGarden(lavLeft, -200f);
                    if(lavRight != null) hideGarden(lavRight, 200f);

                    // Show Text
                    txtRes.setVisibility(View.VISIBLE);
                    txtRes.setAlpha(0f);
                    txtRes.setScaleY(0f);
                    txtRes.animate().alpha(1f).scaleY(1f).setDuration(800)
                            .setStartDelay(500).setInterpolator(new OvershootInterpolator());

                    isLetterOpen = true;
                }
                int r = new Random().nextInt(letters.length);
                txtRes.setText("✨\n" + letters[r] + "\n✨");
            });
        }

        // --- 5. CALENDAR ---
        if (cal != null && dateLbl != null) {
            cal.setOnDateChangeListener((view, year, month, day) -> {
                selectedDate = day + "/" + (month+1) + "/" + year;
                dateLbl.setText("Plan For: " + selectedDate + " 📝");
            });
        }

        // --- 6. NAV AND BUTTONS (Bounce Effect) ---
        setupClick(findViewById(R.id.btnToDoNote));
        setupClick(findViewById(R.id.boxFear));
        setupClick(findViewById(R.id.boxHappy));
        setupClick(findViewById(R.id.boxAnger));
        setupClick(findViewById(R.id.boxSad));

        // Footer Actions
        View navSOS = findViewById(R.id.navSOS);
        if(navSOS != null) navSOS.setOnClickListener(v -> Toast.makeText(this, "Sending Help...", Toast.LENGTH_LONG).show());

        View navProfile = findViewById(R.id.navProfile);
        if(navProfile != null) {
            navProfile.setOnClickListener(v -> {
                // Logout Logic
                new AppPreferences(this).logout();
                startActivity(new Intent(this, SplashActivity.class));
                finish();
            });
        }
    }

    // --- ANIMATION HELPERS ---
    private void startSwaying(View v, int duration, float from, float to) {
        if(v == null) return;
        ObjectAnimator anim = ObjectAnimator.ofFloat(v, "rotation", from, to, from);
        anim.setDuration(duration);
        anim.setRepeatCount(ObjectAnimator.INFINITE);
        anim.start();
    }

    private void rotateObj(View v, int duration) {
        if(v == null) return;
        ObjectAnimator anim = ObjectAnimator.ofFloat(v, "rotation", 0f, 360f);
        anim.setDuration(duration);
        anim.setRepeatCount(ObjectAnimator.INFINITE);
        anim.start();
    }

    private void hideGarden(View v, float xDir) {
        if(v == null) return;
        v.animate()
                .translationY(600f).translationX(xDir).alpha(0f)
                .setDuration(1200).setInterpolator(new AccelerateInterpolator())
                .start();
    }

    private void setupClick(View v) {
        if(v != null) {
            v.setOnClickListener(click -> {
                v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).withEndAction(() ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100)
                );
                Toast.makeText(this, "Section Opened", Toast.LENGTH_SHORT).show();
            });
        }
    }
}