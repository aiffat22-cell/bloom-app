package com.example.bloomapp;

import android.content.Context;
import android.content.SharedPreferences;

public class AppPreferences {
    private final SharedPreferences prefs;
    private final SharedPreferences.Editor editor;

    public AppPreferences(Context context) {
        prefs = context.getSharedPreferences("BloomPrefs", Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    public void setLanguage(String lang) { editor.putString("LANG", lang).apply(); }
    public String getLanguage() { return prefs.getString("LANG", "en"); }

    public void setLoggedIn(boolean status, String username) {
        editor.putBoolean("LOGGED_IN", status).putString("USER", username).apply();
    }
    public boolean isLoggedIn() { return prefs.getBoolean("LOGGED_IN", false); }
    public String getCurrentUser() { return prefs.getString("USER", "Guest"); }
    public void logout() { editor.remove("LOGGED_IN").remove("USER").apply(); }
}