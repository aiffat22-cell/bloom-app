package com.example.bloomapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        DatabaseHelper db = new DatabaseHelper(this);
        View btn = findViewById(R.id.btnLoginAction);

        if (btn != null) {
            btn.setOnClickListener(v -> {
                EditText uBox = findViewById(R.id.inputUsername);
                EditText pBox = findViewById(R.id.inputPassword);
                String u = uBox.getText().toString().trim();
                String p = pBox.getText().toString().trim();

                if (u.isEmpty() || p.isEmpty()) {
                    Toast.makeText(this, "Empty fields", Toast.LENGTH_SHORT).show();
                } else if (db.checkUser(u, p)) {
                    new AppPreferences(this).setLoggedIn(true, u);
                    Intent i = new Intent(this, MainActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                } else {
                    Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            });
        }

        View back = findViewById(R.id.btnBack);
        if(back != null) back.setOnClickListener(v -> finish());
    }
}