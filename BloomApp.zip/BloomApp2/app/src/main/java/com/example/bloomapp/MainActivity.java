package com.example.bloomapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AppPreferences prefs = new AppPreferences(this);
        DatabaseHelper db = new DatabaseHelper(this);

        String username = prefs.getCurrentUsername();
        String realName = db.getFullName(username);

        // Display Name
        TextView txtName = findViewById(R.id.txtName);
        txtName.setText(realName);

        // Logout
        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            prefs.logout();
            // Go back to the very start
            Intent intent = new Intent(this, SplashActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}