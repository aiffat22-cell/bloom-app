package com.example.bloomapp;

import android.content.Intent;
import android.os.Bundle;

public class WelcomeActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        // Go to Auth (Next / Get Started)
        findViewById(R.id.btnGetStarted).setOnClickListener(v -> gotoAuth());
        findViewById(R.id.btnNext).setOnClickListener(v -> gotoAuth());

        // Back to Language
        findViewById(R.id.btnBack).setOnClickListener(v -> {
            startActivity(new Intent(this, LanguageActivity.class));
            finish();
        });
    }

    private void gotoAuth() {
        startActivity(new Intent(this, AuthSelectionActivity.class));
    }
}