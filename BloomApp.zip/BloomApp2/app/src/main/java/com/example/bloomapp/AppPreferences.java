package com.example.bloomapp;

import android.content.Context;
import android.content.SharedPreferences;

public class AppPreferences {
    private final SharedPreferences sharedPreferences;
    private final SharedPreferences.Editor editor;

    public AppPreferences(Context context) {
        sharedPreferences = context.getSharedPreferences("BloomAppPrefs", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    // Language
    public void setLanguage(String lang) { editor.putString("language", lang); editor.apply(); }
    public String getLanguage() { return sharedPreferences.getString("language", "en"); }

    // Session
    public void setLoggedIn(boolean status, String username) {
        editor.putBoolean("isLoggedIn", status);
        editor.putString("current_username", username);
        editor.apply();
    }
    public boolean isLoggedIn() { return sharedPreferences.getBoolean("isLoggedIn", false); }
    public String getCurrentUsername() { return sharedPreferences.getString("current_username", ""); }
    public void logout() {
        editor.remove("isLoggedIn");
        editor.remove("current_username");
        editor.apply();
    }
}