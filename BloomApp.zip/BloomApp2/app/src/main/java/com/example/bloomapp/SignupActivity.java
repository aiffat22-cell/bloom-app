package com.example.bloomapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends BaseActivity {

    DatabaseHelper db; // Declare Database
    SessionManager session; // Declare Session

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Initialize helpers
        db = new DatabaseHelper(this);
        session = new SessionManager(this);

        final EditText inputName = findViewById(R.id.inputName);
        final EditText inputUsername = findViewById(R.id.inputUsername);
        final EditText inputPassword = findViewById(R.id.inputPassword);
        final EditText inputConfirmPass = findViewById(R.id.inputConfirmPass);
        Button btnSignupAction = findViewById(R.id.btnSignupAction);

        btnSignupAction.setOnClickListener(v -> {
            String name = inputName.getText().toString().trim();
            String username = inputUsername.getText().toString().trim();
            String password = inputPassword.getText().toString().trim();
            String confirmPass = inputConfirmPass.getText().toString().trim();

            if(name.isEmpty() || username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            }
            else if (!password.equals(confirmPass)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            }
            else {
                // SAVE TO SQLITE DATABASE
                boolean isInserted = db.addUser(name, username, password);

                if (isInserted) {
                    Toast.makeText(this, "Registration Successful!", Toast.LENGTH_SHORT).show();

                    // Remember this user and Log them in immediately
                    session.createLoginSession(username);

                    // Go to Home
                    Intent intent = new Intent(SignupActivity.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(this, "Username already exists!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }
}