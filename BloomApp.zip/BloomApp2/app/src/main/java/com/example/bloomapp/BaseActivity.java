package com.example.bloomapp;

import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        // 1. Get the latest Language Setting
        AppPreferences prefs = new AppPreferences(newBase);
        String langCode = prefs.getLanguage(); // "ar" or "en"

        // 2. Force the App to switch to that language
        Context context = LocaleHelper.setLocale(newBase, langCode);
        super.attachBaseContext(context);
    }
}