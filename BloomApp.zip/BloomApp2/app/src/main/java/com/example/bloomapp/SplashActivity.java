package com.example.bloomapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

// Note: Extend BaseActivity so language is applied to Splash too!
public class SplashActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(() -> {
            AppPreferences prefs = new AppPreferences(this);
            if (prefs.isLoggedIn()) {
                startActivity(new Intent(this, MainActivity.class));
            } else {
                startActivity(new Intent(this, LanguageActivity.class));
            }
            finish();
        }, 3000);
    }
}