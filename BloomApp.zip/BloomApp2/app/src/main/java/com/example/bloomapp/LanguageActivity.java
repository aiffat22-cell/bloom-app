package com.example.bloomapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

// Temporary: Removed 'extends BaseActivity' to fix the crash.
// We will add it back once the page opens correctly.
public class LanguageActivity extends BaseActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        AppPreferences prefs = new AppPreferences(this);

        // Find Views SAFELY
        View btnEnglish = findViewById(R.id.btnEnglish);
        View btnArabic = findViewById(R.id.btnArabic);

        // Add Listeners only if the button actually exists
        if (btnEnglish != null) {
            btnEnglish.setOnClickListener(v -> {
                prefs.setLanguage("en");
                goToNextPage();
            });
        }

        if (btnArabic != null) {
            btnArabic.setOnClickListener(v -> {
                prefs.setLanguage("ar");
                goToNextPage();
            });
        }
    }

    private void goToNextPage() {
        // Clear activity stack so they don't come back here on "Back"
        Intent intent = new Intent(LanguageActivity.this, WelcomeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}