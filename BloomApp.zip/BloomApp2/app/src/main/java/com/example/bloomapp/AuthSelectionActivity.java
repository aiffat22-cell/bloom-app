package com.example.bloomapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class AuthSelectionActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth_selection);

        findViewById(R.id.btnLogin).setOnClickListener(v -> startActivity(new Intent(this, LoginActivity.class)));
        findViewById(R.id.btnSignup).setOnClickListener(v -> startActivity(new Intent(this, SignupActivity.class)));
        findViewById(R.id.btnBack).setOnClickListener(v -> finish()); // Go back

        // Dummy Social Login
        findViewById(R.id.iconGoogle).setOnClickListener(v -> fakeLogin("Google"));
        findViewById(R.id.iconFacebook).setOnClickListener(v -> fakeLogin("Facebook"));
    }

    private void fakeLogin(String provider) {
        AppPreferences prefs = new AppPreferences(this);
        DatabaseHelper db = new DatabaseHelper(this);

        // Add dummy user so DB check doesn't crash app
        if(!db.checkUser(provider, "123")) db.addUser(provider + " User", provider, "123");

        prefs.setLoggedIn(true, provider);
        Toast.makeText(this, "Logged in via " + provider, Toast.LENGTH_SHORT).show();
        startActivity(new Intent(this, MainActivity.class));
        finish();
        View btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish()); // Go back to Welcome
        }   }
    // Inside AuthSelectionActivity.java

}